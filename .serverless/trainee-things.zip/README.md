# trainee-things

This project is only for trainee purposes!

## Serverless
First configure serverless to use the correct credentials:
``serverless config credentials --provider aws --key <your_key> --secret <your_secret>``
If you already have configured a profiel you can overwrite it with the the parameter ```-o```

The service can be deployed with following command:
``serverless deploy``


serverless config credentials --provider aws --key AKIATMKEO5LDEXVPAZHC --secret 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